// pg-app.jsx — Plastiglom design canvas
// Five iPhone screens side-by-side as DCArtboards, in light or dark.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "both",
  "substrate": 0.55,
  "accent": "amber",
  "screen": "all"
}/*EDITMODE-END*/;

function phoneArtboard({ id, label, theme, t, Screen }) {
  return (
    <DCArtboard key={id} id={id} label={label} width={460} height={920}>
      <div style={{
        width: '100%', height: '100%',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: 'transparent',
      }}>
        <IOSDevice width={402} height={874} dark={theme.dark}>
          <Screen theme={theme} t={t} />
        </IOSDevice>
      </div>
    </DCArtboard>
  );
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const screens = [
    { id: 'prompt',   label: '01 · Daily Exercise Prompt', Screen: ScreenPrompt },
    { id: 'response', label: '02 · Response Writing',      Screen: ScreenResponse },
    { id: 'archive',  label: '03 · Archive',               Screen: ScreenArchive },
    { id: 'analysis', label: '04 · Analysis',              Screen: ScreenAnalysis },
    { id: 'settings', label: '05 · Settings',              Screen: ScreenSettings },
  ];
  const filtered = t.screen === 'all' ? screens : screens.filter(s => s.id === t.screen);

  // Override accent if asked. Uses post-theme mutation.
  const accentMap = {
    amber:  { light: '#C9802C', dark: '#FFB23A' },
    gold:   { light: '#9C6B26', dark: '#E8A24A' },
    sage:   { light: '#6B8B6E', dark: '#9DC0A1' },
    haze:   { light: '#7E76A0', dark: '#A8A0CC' },
  };
  const applyAccent = (theme) => {
    const a = accentMap[t.accent] || accentMap.amber;
    return { ...theme, amber: theme.dark ? a.dark : a.light, gold: theme.dark ? a.dark : a.light };
  };

  const lightTheme = applyAccent(pgTheme(false));
  const darkTheme  = applyAccent(pgTheme(true));

  return (
    <>
      <DesignCanvas>
        {/* Light row */}
        {(t.theme === 'light' || t.theme === 'both') && (
          <DCSection id="light" title="Light · Frosted Pearl">
            {filtered.map(({ id, label, Screen }) =>
              phoneArtboard({ id: 'l-'+id, label, theme: lightTheme, t, Screen })
            )}
          </DCSection>
        )}

        {/* Dark row */}
        {(t.theme === 'dark' || t.theme === 'both') && (
          <DCSection id="dark" title="Dark · Digital Substrate">
            {filtered.map(({ id, label, Screen }) =>
              phoneArtboard({ id: 'd-'+id, label, theme: darkTheme, t, Screen })
            )}
          </DCSection>
        )}
      </DesignCanvas>

      <TweaksPanel title="Plastiglom · Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Show" value={t.theme}
                    options={['light','dark','both']}
                    onChange={(v) => setTweak('theme', v)} />
        <TweakSelect label="Accent" value={t.accent}
                     options={[
                       { value: 'amber', label: 'Signal amber' },
                       { value: 'gold',  label: 'Kintsugi gold' },
                       { value: 'sage',  label: 'Misted sage' },
                       { value: 'haze',  label: 'Lilac haze' },
                     ]}
                     onChange={(v) => setTweak('accent', v)} />

        <TweakSection label="Substrate" />
        <TweakSlider label="Circuit intensity" value={t.substrate}
                     min={0} max={1} step={0.05}
                     onChange={(v) => setTweak('substrate', v)} />

        <TweakSection label="Focus" />
        <TweakSelect label="Screen" value={t.screen}
                     options={[
                       { value: 'all',      label: 'All screens' },
                       { value: 'prompt',   label: '01 · Prompt' },
                       { value: 'response', label: '02 · Response' },
                       { value: 'archive',  label: '03 · Archive' },
                       { value: 'analysis', label: '04 · Analysis' },
                       { value: 'settings', label: '05 · Settings' },
                     ]}
                     onChange={(v) => setTweak('screen', v)} />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
