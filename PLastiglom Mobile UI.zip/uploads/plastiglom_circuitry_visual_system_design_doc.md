# Plastiglom — Circuitry Visual System Design Doc

## 1. Purpose of this companion doc

This document extends the original Plastiglom design direction into a more synthetic, electronic, plastic, and digital visual system. It should be read as a visual-design companion to the core product architecture document, not as a replacement for the functional requirements.

The app remains a private, single-user self-reflection tool. The visual design should support the following core behaviors:

- receiving a scheduled daily exercise
- writing a response with minimal friction
- editing until the next main exercise fires
- reviewing archived entries
- reading weekly/monthly/ad-hoc analysis
- managing reminders, sync, local vault state, and notification settings

The updated design language moves Plastiglom away from an overly organic interpretation of plastiglomerate. Instead of leaning on pottery, paper, mineral dust, and natural sediment, the interface should interpret plastiglomerate through fused consumer technology: translucent polymer, laminated screen material, smoked acrylic, PCB traces, heat-welded seams, resin bonding lines, and quiet digital artifacts.

The app should feel like a private reflective instrument built out of archived thoughts and repurposed electronic matter.

---

## 2. Core metaphor

### 2.1 Plastiglomerate as synthetic memory

The original metaphor remains: fused fragments of memory, habit, and reflection. The change is in the material vocabulary.

Instead of:

- ceramic shard
- mineral seam
- archive paper
- sedimentary stone
- handmade pottery repair

Use:

- translucent polymer sheet
- smoked acrylic panel
- resin-bonded data slab
- laminated display layer
- quiet circuit trace
- heat-fused seam
- e-waste fragment
- device-shell edge
- local-storage substrate

The interface should suggest that each reflection is a small memory object captured in a private device. Entries are not mystical artifacts or natural stones. They are synthetic fragments of interior life: saved, indexed, locked, analyzed, and preserved locally.

### 2.2 Circuitry as nervous system, not decoration

The circuitry motif should not be applied as random futuristic ornament. It should correspond to the app’s functional model:

- **traces** represent scheduled flows, locks, edits, sync paths, and memory retrieval
- **nodes** represent entries, tags, prompts, and analysis reports
- **lit points** represent active, saved, synced, locked, or selected states
- **broken or interrupted traces** represent null entries, opened-unresponded entries, incomplete sync, or retired exercises
- **layered boards** represent the private vault, local index, archived memory, and analysis history

The user should be able to sense that the system is procedural and local-first, even when they are only looking at a prompt card.

---

## 3. Layout philosophy

### 3.1 Functional hierarchy before aesthetic fracture

The app can be strange, asymmetrical, and symbol-heavy, but fracture must never interfere with reading, writing, editing, searching, or changing settings.

The design should divide screens into two zones:

1. **Functional core zone**  
   The area where the user reads, writes, submits, searches, edits, or changes settings. This zone must remain plain, stable, and highly legible.

2. **Atmospheric substrate zone**  
   The surrounding layer where circuitry, translucent overlaps, seam lines, micro-grids, and digital artifacts can appear. This zone carries the visual identity without competing with the task.

### 3.2 Fracture as containment, not chaos

Fracture should describe panel edges, background surfaces, archive cards, and visual dividers. It should not scatter controls across the screen.

Use fracture for:

- outer card silhouettes
- screen background panels
- archive card boundaries
- material-study swatches
- faint section dividers
- edges of inactive layers
- decorative seams around prompt containers

Avoid fracture for:

- body text blocks
- text input fields
- primary buttons
- reminder time controls
- search fields
- toggles
- bottom navigation labels

A good rule: fracture can frame an interaction, but it should not become the interaction.

### 3.3 Local-first composition

The UI should quietly communicate that the app is private and local-first. This should appear through visual structure:

- contained panels rather than open cloud-like expanses
- vault/status strips at the bottom of settings and writing screens
- lock and local indicators placed near editability states
- subdued cloud/sync icons, never dominant
- small status labels like `local`, `saved`, `synced`, `locked`, `queued`
- internal trace diagrams rather than external network diagrams

The app should feel like it is operating inside the user’s own device, not broadcasting outward.

---

## 4. Circuitry motif

### 4.1 Circuit traces

Circuit traces are thin, mostly low-contrast lines that move behind or along panel edges. They should feel etched into polymer layers or faintly visible beneath translucent surfaces.

Recommended uses:

- behind the Daily Exercise Prompt panel
- along the bottom third of the Analysis screen
- inside archive-card backgrounds at very low opacity
- behind settings groups as subtle system diagramming
- in material swatches and design-board annotations

Trace behavior:

- mostly orthogonal with occasional angled joins
- never dense enough to look like a motherboard screenshot
- small breaks, offsets, and alignment shifts are allowed
- active paths can use tiny amber points
- inactive paths remain gray, smoke, or pearl

### 4.2 Nodes

Nodes are small points on traces. They can represent system states or user-data objects.

Use node styles for:

- submitted entries
- synced entries
- local-only drafts
- active prompt
- selected cadence
- locked state
- tags
- analysis themes

Node states:

| State | Visual treatment |
|---|---|
| Active | softly lit amber point |
| Submitted | solid small point or filled chip |
| Local | hollow point with dim rim |
| Synced | filled point with quiet check mark |
| Null | unlit hollow point |
| Opened-unresponded | broken-ring point |
| Locked | small point inside lock outline |
| Queued | pulsing/dotted point, not animated in static mockups |

### 4.3 Micro-grids

Micro-grids should be used as the digital equivalent of grain. They replace paper texture and ceramic speckling.

Use grids as:

- faint background alignment systems
- screen-edge details
- analysis-report texture
- data-slab card texture
- design-board scaffolding

Grid rules:

- grid lines should be barely visible
- avoid obvious blueprint styling
- grids should fade near text-heavy areas
- do not use grids behind long writing input text unless opacity is extremely low

### 4.4 Digital artifacts

Digital artifacts should be subtle and controlled.

Allowed artifacts:

- tiny scanline hints
- low-opacity pixel dust
- LCD subpixel speckle
- ghosted alignment ticks
- faint compression-like blocks
- light sensor dots
- barely visible device-edge seams

Avoid:

- glitch effects over text
- heavy chromatic aberration
- noisy CRT distortion
- cyberpunk overload
- loud holographic effects
- decorative fake code blocks

---

## 5. Fractured structure

### 5.1 Fused panels

Fused panels are the main structural motif. They should look like two or more synthetic surfaces laminated together.

Panel construction:

- base rounded rectangle for usability
- secondary offset slab underneath or inside
- asymmetrical fused corner or side tab
- thin seam line where layers meet
- small node/trace detail near seam
- mild translucent overlap

The Daily Exercise Prompt screen may use the strongest fused-panel shape. The Response Writing screen should use the least fractured version.

### 5.2 Resin seams instead of kintsugi

The earlier organic direction used kintsugi-like repair seams. The revised direction should translate this into:

- translucent bonding seams
- heat-welded plastic joins
- faint amber resin lines
- lamination boundaries
- embedded conductive filaments

Seams should feel functional and manufactured. They should not look like gold cracks in pottery.

### 5.3 Archive slabs

Archive entries should resemble collected synthetic memory fragments.

Each archive card may include:

- translucent smoked panel body
- tiny embedded trace pattern
- date/time as a small technical label
- title in readable editorial weight
- tags as small chips or node capsules
- status indicator on the right
- faint seam or notch along one edge

The archive should be straightforward and readable. The fragment motif should make entries feel preserved, not buried.

### 5.4 Analysis panels

Analysis reports should use a calmer fractured structure. They are reading surfaces, not expressive prompt cards.

Use:

- clean rectangular sections
- thin dividers
- faint circuitry at margins
- subtle bottom substrate texture
- strong heading hierarchy
- tags as contained chips

Avoid:

- chat bubbles
- assistant/persona avatars
- conversational layout
- overly decorative analysis cards

The analysis screen should feel like a private report generated from local memory.

---

## 6. Symbology

### 6.1 Symbol principles

Symbols should feel discovered inside the system, not like a heavily branded icon set. They can be abstract, but they must remain learnable.

Use consistent recurring symbols for:

- prompt / daily exercise
- archive
- analysis
- settings
- morning
- evening
- saved
- local
- synced
- locked
- editable
- null
- opened-unresponded
- Telegram notification
- private vault

### 6.2 Core icon vocabulary

| Meaning | Suggested symbol |
|---|---|
| Daily prompt | small starburst, active node, or layered prompt tile |
| Morning | restrained sunburst or small radial mark |
| Evening | crescent or dimmed radial mark |
| Archive | stacked translucent slabs |
| Analysis | angular line graph or signal trace |
| Settings | gear, hex-nut, or device-control glyph |
| Saved locally | check inside small local node or shield |
| Synced | small cloud outline with node indicator |
| Locked | simple lock with tiny status point |
| Editable | pencil or open seam mark |
| Null | hollow unlit node |
| Opened-unresponded | broken ring node |
| Private vault | shield, safe-box outline, or enclosed cube |
| Telegram notification | minimal paper-plane symbol, secondary only |

### 6.3 Symbol density

Symbol density can be higher on the design board and lower in the actual app UI.

Recommended density:

- Daily Prompt: medium-high, because it carries the identity
- Response Writing: low, because it must prioritize typing
- Archive: medium, because statuses and tags benefit from icon support
- Analysis: low-medium, because report reading must remain calm
- Settings: medium, because system state and local-first status need clarity

---

## 7. Typography

Typography should remain readable and slightly editorial, but the electronic direction allows more monospaced and system-like details.

Recommended pairing:

- **Primary UI sans:** humanist or neo-grotesk sans, readable at small sizes
- **Long-form writing font:** highly legible sans or gentle serif; avoid novelty
- **Micro-label font:** optional mono or semi-mono for timestamps, statuses, and system labels

Use mono-like typography sparingly:

- timestamps
- lock times
- local/synced labels
- small technical annotations
- index-like labels on design-board fragments

Avoid making all body text monospaced unless intentionally chosen for the response-writing field.

---

# Light Mode Visual System

## 8. Light mode concept

Light mode should feel like frosted synthetic material under soft daylight. It should not return to earth tones or natural paper. The surface language is:

- pale polymer
- frosted acrylic
- translucent device-shell plastic
- white-gray laminated panels
- soft graphite text
- tiny amber signal points
- faint gray circuit traces

The light mode is quiet, reflective, and intimate, but more technological than organic.

## 9. Light mode color palette

### 9.1 Base palette

| Token | Suggested color | Use |
|---|---:|---|
| `lm-bg-base` | `#F3F4F6` | app background / board field |
| `lm-bg-panel` | `#E9EAED` | major cards and screens |
| `lm-bg-elevated` | `#F8F8F6` | text fields, report sections |
| `lm-polymer-bone` | `#E6E7EA` | translucent surfaces |
| `lm-polymer-beige` | `#DCD9D3` | warmer neutral panels |
| `lm-smoked-gray` | `#B7BBC2` | borders, muted containers |
| `lm-graphite-mist` | `#8E939A` | secondary text, disabled states |
| `lm-muted-sage` | `#A6ADA5` | low-emphasis status accents |
| `lm-lilac-haze` | `#C5C3D6` | occasional reflective accent |
| `lm-signal-amber` | `#F6B26B` | active node, selected state, subtle signal |
| `lm-text-primary` | `#15181D` | main text |
| `lm-text-secondary` | `#4F5660` | metadata and descriptions |

### 9.2 Light mode contrast rules

- Prompt and report text must stay near `lm-text-primary`.
- Metadata can use `lm-text-secondary`, but never below readable contrast.
- Amber is an accent, not a CTA color by default.
- Primary actions may use dark graphite fill with light text.
- Secondary actions use translucent borders and pale fills.

### 9.3 Light mode surface treatments

Use:

- 1px cool-gray borders
- 2–8% noise or LCD grain
- low-opacity micro-grid in background
- translucent overlays at 5–18% opacity
- faint inner shadow for frosted panels
- small amber pinlights at active nodes

Avoid:

- beige paper backgrounds
- heavy shadow skeuomorphism
- strong glassmorphism blur everywhere
- bright wellness gradients
- pure white sterile surfaces

## 10. Light mode screen guidance

### 10.1 Daily Exercise Prompt

The prompt screen may be the most atmospheric light-mode screen.

Use:

- large translucent fused prompt panel
- soft circuit traces visible behind panel edges
- pale synthetic gradients from pearl to smoke
- small active amber node near prompt metadata
- fractured panel edge, but text centered and stable

The prompt card should feel like a held piece of synthetic memory.

### 10.2 Response Writing

The writing screen should be plain, calm, and functional.

Use:

- nearly flat light panel
- large text area with high contrast
- lock state as a compact system strip
- Save Draft and Submit as visually distinct but not loud
- local/saved indicator at bottom edge of writing field

Avoid decorative traces inside the active text-entry area.

### 10.3 Archive

Archive cards should resemble stacked memory slabs.

Use:

- translucent card stack
- faint embedded traces
- small local/synced/null status nodes
- tags as compact capsules
- search and filters in conventional readable forms

### 10.4 Analysis

Analysis should look like a private report.

Use:

- clean sections with crisp dividers
- soft circuit substrate at bottom or margins
- cadence controls as segmented chips
- recurring themes as subdued tags
- minimal decoration near body text

### 10.5 Settings / Reminders

Settings should feel like a local device control panel.

Use:

- grouped settings rows
- private vault status strip
- subtle device-shell border
- clear time chips for 07:30 / 21:00
- notification toggles with restrained amber active state

---

# Dark Mode Visual System

## 11. Dark mode concept

Dark mode should feel like looking into a private device at night. It is not aggressive cyberpunk. It is a quiet local system with dim circuitry and smoked plastic surfaces.

The surface language is:

- digital black
- graphite shell
- smoked translucent polymer
- dim amber LED points
- low-glow circuit traces
- private vault interface
- soft phosphor-like text highlights

Dark mode should feel more intimate than light mode, but not more cluttered.

## 12. Dark mode color palette

### 12.1 Base palette

| Token | Suggested color | Use |
|---|---:|---|
| `dm-bg-base` | `#0A0D10` | app background / board field |
| `dm-bg-panel` | `#0F1216` | major panels |
| `dm-bg-elevated` | `#151A21` | cards, writing areas |
| `dm-polymer-base` | `#1C222B` | translucent slabs |
| `dm-smoked-gray` | `#2A313B` | borders and inactive surfaces |
| `dm-graphite-mist` | `#363E4A` | secondary surfaces |
| `dm-deep-smoke` | `#3F4854` | high surfaces, selected cards |
| `dm-muted-sage` | `#4A5552` | secondary status color |
| `dm-violet-haze` | `#5A5069` | rare contemplative accent |
| `dm-signal-amber` | `#FFB23A` | active state, signal, selected tab |
| `dm-signal-amber-dim` | `#9A641D` | low-intensity amber linework |
| `dm-text-primary` | `#F3F4F6` | main text |
| `dm-text-secondary` | `#B7BBC2` | metadata and supporting text |
| `dm-text-muted` | `#7B838E` | inactive labels |

### 12.2 Dark mode contrast rules

- Body text must remain bright enough for long-form reading.
- Avoid placing light text over noisy trace fields.
- Amber should mark active states, not flood the screen.
- Borders should be visible but soft.
- Inputs should be clearly separated from decorative background layers.

### 12.3 Dark mode surface treatments

Use:

- smoked-glass panels
- subtle inner glow around active panels
- 1px graphite borders
- dim amber trace endpoints
- low-opacity grid and circuit substrate
- soft reflections at panel corners
- faint blue-gray shadow rather than pure black shadows

Avoid:

- saturated neon blues/pinks
- gamer dashboard styling
- heavy glow halos
- sci-fi clutter
- overly dense fake circuitry
- unreadable dark-on-dark controls

## 13. Dark mode screen guidance

### 13.1 Daily Exercise Prompt

The prompt screen is the identity anchor in dark mode.

Use:

- smoked translucent fused panel
- amber-lit trace fragments around the panel edges
- dark graphite backing surface
- soft white prompt text
- small active node near `Main · Evening · est. 8 min`

This screen should feel like a reflection prompt suspended inside a private circuit board.

### 13.2 Response Writing

The writing screen must remain restrained.

Use:

- deep elevated editor surface
- body text in high-contrast off-white
- lock/edit state in a compact dark system strip
- Save Draft as quiet secondary button
- Submit as dark button with amber outline or amber text
- local/saved indicator in muted text

Do not let circuitry sit directly behind the response body.

### 13.3 Archive

Archive cards in dark mode should look like collected data fragments.

Use:

- dark translucent slabs
- amber or sage status dots
- subtle linework behind card edges
- tags as low-contrast dark pills
- active Archive nav item in amber

Null/opened-unresponded entries should be visually quieter, not alarm-colored.

### 13.4 Analysis

Analysis should read like a night-mode report.

Use:

- crisp section titles
- low-glow dividers
- faint technical substrate at bottom
- active cadence tab in amber outline/fill
- recurring theme chips in dark graphite

The analysis screen should preserve a blunt, report-like tone.

### 13.5 Settings / Reminders

Settings should become a private system panel.

Use:

- grouped rows on deep elevated surfaces
- amber toggle active states
- private vault strip as a persistent trust cue
- small device-control symbols
- compact time selectors

The visual message: this system is local, contained, and under the user’s control.

---

## 14. Shared component rules

### 14.1 Buttons

| Button type | Light mode | Dark mode |
|---|---|---|
| Primary | graphite fill, pale text | dark fill, amber outline or amber text |
| Secondary | translucent pale fill, graphite text | smoked fill, pale text |
| Text/action | small icon + label | small icon + label |
| Destructive | avoid unless needed; muted rust | muted rust, low saturation |

Primary buttons should be clear, but not corporate or loud.

### 14.2 Tags

Tags should be small, tactile chips.

Light mode:

- pale translucent fill
- thin gray border
- graphite text

Dark mode:

- graphite fill
- dim border
- pale text
- optional tiny node dot for active tags

### 14.3 Status strips

Status strips communicate local-first behavior.

Common examples:

- `Saved locally`
- `Private vault active`
- `Editable until next main fire · lock at 07:30`
- `Queued for sync`
- `Synced`

Status strips should be quiet but unmistakable. They are part of the trust layer.

### 14.4 Bottom navigation

Bottom navigation should remain conventional.

Recommended items:

- Today
- Archive
- Analysis
- Settings

The selected item can use:

- filled icon
- amber node
- brighter text
- subtle top line

Do not fracture bottom navigation. It is a core usability structure.

---

## 15. Design-board guidance

When producing visual mockups or design boards, include:

- five mobile screens
- left-side palette strip
- material study chips
- icon study
- UI fragments
- small annotations
- private/local notes
- a small synthetic plastiglomerate emblem

The design board itself can be denser than the app. It is allowed to show the motif in a more concentrated way so that the visual system is understandable.

However, actual app screens should be calmer than the board.

---

## 16. Avoid list

Avoid these visual directions:

- generic meditation app
- cute wellness mascot
- corporate SaaS dashboard
- bright wellness gradients
- sterile Apple-style minimalism
- pottery / ceramic cliché
- beige paper scrapbook style
- realistic rock or mineral photography
- aggressive cyberpunk neon
- gamer HUD
- occult symbols
- overbuilt glyph dictionary
- chatbot conversation layout for analysis
- illegible glitch text
- fake code rain
- excessive glassmorphism

---

## 17. Summary design statement

Plastiglom’s updated visual system should feel like a quiet reflective device made of fused synthetic memory fragments. The circuitry motif represents scheduled introspection, local archival, edit locks, memory retrieval, and analysis. The fractured structure gives the app its identity, but the functional core always remains readable and stable.

Light mode should feel like frosted polymer under soft daylight. Dark mode should feel like a private smoked-glass device at night. Both modes should share the same logic: local-first, reflective, synthetic, fractured, and quietly technical.