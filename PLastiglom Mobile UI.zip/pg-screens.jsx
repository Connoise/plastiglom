// pg-screens.jsx
// All five Plastiglom screens. Each takes { theme, t } where:
//   theme = palette object derived from light/dark
//   t = tweak values
//
// Screens: ScreenPrompt, ScreenResponse, ScreenArchive, ScreenAnalysis, ScreenSettings

// ─────────────────────────────────────────────────────────────
// Palette factory — derived from the mockup swatches
// ─────────────────────────────────────────────────────────────
function pgTheme(dark) {
  if (dark) return {
    dark: true,
    bg:        '#060709',
    bgInk:     '#0E1216',   // frosted pearl
    surface:   '#161B21',   // translucent
    surface2:  '#1B2128',   // polymer base
    surface3:  '#22272F',   // smoked gray
    line:      '#2F363F',
    lineSoft:  'rgba(220,225,235,0.08)',
    text:      '#F3F4F6',
    textDim:   'rgba(220,225,235,0.62)',
    textFaint: 'rgba(220,225,235,0.32)',
    gold:      '#FFB23A',   // resin/amber seam
    amber:     '#FFB23A',   // signal
    amberDim:  '#9A641D',
    sage:      '#4A5552',
    haze:      '#5A5069',
    chrome:    'rgba(14,18,22,0.88)',
    chromeBd:  'rgba(220,225,235,0.10)',
  };
  return {
    dark: false,
    bg:        '#F3F4F6',
    bgInk:     '#E9EAED',
    surface:   '#F8F8F6',   // elevated
    surface2:  '#ECEDEB',   // polymer bone
    surface3:  '#E6E3DE',   // polymer beige
    line:      '#C9CDD1',   // smoked gray
    lineSoft:  'rgba(40,46,54,0.12)',
    text:      '#15181D',
    textDim:   'rgba(21,24,29,0.64)',
    textFaint: 'rgba(21,24,29,0.36)',
    gold:      'rgba(176,122,46,0.85)',
    amber:     '#E0A040',
    amberDim:  '#B07A2E',
    sage:      '#AEB5AF',
    haze:      '#D9D6E7',
    chrome:    'rgba(248,248,246,0.92)',
    chromeBd:  'rgba(40,46,54,0.10)',
  };
}

// ─────────────────────────────────────────────────────────────
// Background substrate — circuit-board / contour texture
// Drawn once per screen as an absolute layer behind content.
// ─────────────────────────────────────────────────────────────
function PGSubstrate({ theme, intensity = 0.55, seed = 3 }) {
  const dark = theme.dark;
  // procedural circuit nodes + connecting paths
  const rng = (n) => { let s = seed * 9301 + n * 49297; s = (s % 233280) / 233280; return s; };
  const nodes = [];
  const traces = [];
  const lineColor = dark ? 'rgba(232,162,74,0.22)' : 'rgba(60,55,45,0.18)';
  const dotColor  = dark ? 'rgba(255,178,58,0.55)' : 'rgba(60,55,45,0.30)';
  const W = 402, H = 874;

  // grid of jittered nodes
  for (let i = 0; i < 38; i++) {
    const x = (rng(i*3) * W);
    const y = (rng(i*3+1) * H);
    const big = rng(i*3+2) > 0.85;
    nodes.push(<circle key={'n'+i} cx={x} cy={y} r={big ? 1.6 : 0.7} fill={dotColor} />);
  }
  // orthogonal traces
  for (let i = 0; i < 22; i++) {
    const x1 = rng(i*5) * W;
    const y1 = rng(i*5+1) * H;
    const horizontal = rng(i*5+2) > 0.5;
    const len = 40 + rng(i*5+3) * 180;
    const x2 = horizontal ? x1 + len : x1;
    const y2 = horizontal ? y1 : y1 + len;
    // sometimes bend
    const bend = rng(i*5+4) > 0.5;
    if (bend) {
      const mx = horizontal ? x2 : x1;
      const my = horizontal ? y1 : y2;
      const x3 = horizontal ? x2 : x2 + (rng(i+9) > 0.5 ? 60 : -60);
      const y3 = horizontal ? y2 + (rng(i+9) > 0.5 ? 60 : -60) : y2;
      traces.push(
        <path key={'t'+i}
              d={`M${x1.toFixed(1)},${y1.toFixed(1)} L${mx.toFixed(1)},${my.toFixed(1)} L${x3.toFixed(1)},${y3.toFixed(1)}`}
              stroke={lineColor} strokeWidth="0.5" fill="none" />
      );
    } else {
      traces.push(
        <line key={'t'+i} x1={x1} y1={y1} x2={x2} y2={y2}
              stroke={lineColor} strokeWidth="0.5" />
      );
    }
  }
  // hex emblems (rare)
  const hexes = [];
  for (let i = 0; i < 4; i++) {
    const cx = rng(i*11) * W;
    const cy = 120 + rng(i*11+1) * (H - 240);
    const r = 12 + rng(i*11+2) * 18;
    const pts = [];
    for (let k = 0; k < 6; k++) {
      const a = (Math.PI / 3) * k;
      pts.push(`${(cx + Math.cos(a)*r).toFixed(1)},${(cy + Math.sin(a)*r).toFixed(1)}`);
    }
    hexes.push(<polygon key={'h'+i} points={pts.join(' ')} fill="none" stroke={lineColor} strokeWidth="0.4" />);
  }

  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: dark
        ? 'radial-gradient(120% 80% at 30% 20%, #141B22 0%, #0A0D10 65%, #06080A 100%)'
        : 'radial-gradient(120% 80% at 30% 20%, #FAFAF8 0%, #ECEDEF 65%, #DDDFE3 100%)',
      overflow: 'hidden',
    }}>
      <svg width="100%" height="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid slice"
           style={{ position: 'absolute', inset: 0, opacity: intensity }}>
        {traces}
        {hexes}
        {nodes}
      </svg>
      {/* warm glow spots in dark mode */}
      {dark && (
        <div style={{
          position: 'absolute', inset: 0,
          background: 'radial-gradient(60px 40px at 70% 30%, rgba(255,178,58,0.18), transparent 70%),'
                    + 'radial-gradient(80px 50px at 20% 70%, rgba(255,178,58,0.10), transparent 70%),'
                    + 'radial-gradient(50px 30px at 85% 80%, rgba(255,178,58,0.14), transparent 70%)',
          pointerEvents: 'none',
        }} />
      )}
      <PGGrain dark={dark} opacity={dark ? 0.35 : 0.45} seed={seed + 1} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Fused-panel — asymmetric polygon card with optional kintsugi seam
// (Re-implemented locally so we control padding + inner shadow precisely)
// ─────────────────────────────────────────────────────────────
function FusedPanel({ theme, children, variant = 0, style = {}, seam = true, padded = true, notch = true }) {
  const dark = theme.dark;
  // Rounded-octagon panels matching the asset library — soft, laminated polymer feel.
  const clips = [
    'polygon(8% 0, 92% 0, 100% 8%, 100% 92%, 92% 100%, 8% 100%, 0 92%, 0 8%)',
    'polygon(10% 0, 90% 0, 100% 10%, 100% 90%, 90% 100%, 10% 100%, 0 90%, 0 10%)',
    'polygon(6% 0, 94% 0, 100% 6%, 100% 94%, 88% 100%, 6% 100%, 0 88%, 0 12%)',
    'polygon(10% 0, 92% 2%, 100% 12%, 100% 88%, 90% 100%, 8% 100%, 0 92%, 0 10%)',
    'polygon(8% 0, 92% 0, 100% 10%, 100% 90%, 92% 100%, 8% 100%, 0 90%, 0 10%)',
  ];
  const clip = clips[variant % clips.length];
  const fill = dark ? 'rgba(22,27,33,0.78)' : 'rgba(255,255,254,0.82)';
  const inner = dark
    ? '0 0 0 1px rgba(220,225,235,0.06) inset, 0 1px 0 rgba(255,255,255,0.03) inset'
    : '0 0 0 1px rgba(40,46,54,0.10) inset, 0 1px 0 rgba(255,255,255,0.7) inset';

  // faint resin seam path inside the panel (drawn at panel coords)
  const seamPath = "M 8 18 C 30 24, 60 14, 96 22 S 180 38, 240 22 S 360 30, 392 18";

  return (
    <div style={{
      position: 'relative',
      background: fill,
      backdropFilter: 'blur(18px) saturate(140%)',
      WebkitBackdropFilter: 'blur(18px) saturate(140%)',
      clipPath: clip,
      WebkitClipPath: clip,
      boxShadow: inner,
      padding: padded ? '28px 24px' : 0,
      ...style,
    }}>
      {/* faint embedded trace at top-right notch */}
      {notch && (
        <svg style={{ position: 'absolute', top: 6, right: 8, width: 22, height: 22,
                      pointerEvents: 'none' }} viewBox="0 0 22 22">
          <path d="M2 2 L11 2 L20 11" fill="none"
                stroke={dark ? 'rgba(220,225,235,0.18)' : 'rgba(40,46,54,0.18)'}
                strokeWidth="0.7" />
          <circle cx="11" cy="2" r="1" fill={theme.amber} opacity="0.8" />
        </svg>
      )}
      {seam && (
        <svg style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none' }}
             preserveAspectRatio="none" viewBox="0 0 400 600">
          <path d={seamPath} fill="none" stroke={theme.gold} strokeWidth="0.8" opacity="0.55" />
        </svg>
      )}
      <div style={{ position: 'relative', zIndex: 1 }}>{children}</div>
    </div>
  );
}

function CornerTicks({ theme }) {
  const c = theme.dark ? 'rgba(232,162,74,0.55)' : 'rgba(60,55,45,0.40)';
  const tick = (style) => (
    <div style={{
      position: 'absolute', width: 8, height: 8,
      borderColor: c, ...style,
    }} />
  );
  return (
    <>
      {tick({ top: 8,  left: 8,  borderTop: `0.8px solid ${c}`, borderLeft: `0.8px solid ${c}` })}
      {tick({ top: 8,  right: 8, borderTop: `0.8px solid ${c}`, borderRight: `0.8px solid ${c}` })}
      {tick({ bottom: 8, left: 8,  borderBottom: `0.8px solid ${c}`, borderLeft: `0.8px solid ${c}` })}
      {tick({ bottom: 8, right: 8, borderBottom: `0.8px solid ${c}`, borderRight: `0.8px solid ${c}` })}
    </>
  );
}

// Tag chip
function Tag({ theme, children, variant = 'default' }) {
  const dark = theme.dark;
  const bg = variant === 'amber'
    ? (dark ? 'rgba(255,178,58,0.14)' : 'rgba(201,128,44,0.12)')
    : (dark ? 'rgba(232,226,210,0.06)' : 'rgba(26,26,31,0.05)');
  const fg = variant === 'amber' ? theme.amber : theme.textDim;
  const bd = variant === 'amber'
    ? (dark ? 'rgba(255,178,58,0.30)' : 'rgba(201,128,44,0.30)')
    : theme.lineSoft;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', height: 22,
      padding: '0 9px', borderRadius: 4,
      fontFamily: 'JetBrains Mono, ui-monospace, monospace',
      fontSize: 10.5, letterSpacing: 0.4, textTransform: 'lowercase',
      background: bg, color: fg, border: `0.5px solid ${bd}`,
    }}>{children}</span>
  );
}

// ─────────────────────────────────────────────────────────────
// Top app bar (used by all in-app screens, replaces nav title)
// ─────────────────────────────────────────────────────────────
function PGAppBar({ theme, title, subtitle, leading, trailing, large = false }) {
  return (
    <div style={{
      position: 'relative', zIndex: 5,
      padding: large ? '62px 20px 12px' : '62px 20px 8px',
      display: 'flex', alignItems: 'flex-start', gap: 12,
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        {leading || (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <PGMark size={22} dark={theme.dark} />
            <div style={{
              fontFamily: 'Fraunces, Georgia, serif',
              fontSize: large ? 26 : 22, fontWeight: 400,
              color: theme.text, letterSpacing: -0.3,
            }}>{title}</div>
          </div>
        )}
        {subtitle && (
          <div style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 10.5, letterSpacing: 0.5, textTransform: 'uppercase',
            color: theme.textDim, marginTop: 6, marginLeft: 32,
          }}>{subtitle}</div>
        )}
      </div>
      {trailing}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Tab bar (bottom)
// ─────────────────────────────────────────────────────────────
function PGTabBar({ theme, active = 'today', onChange = () => {} }) {
  const items = [
    { id: 'today',    label: 'Today',    Icon: IconPrompt },
    { id: 'archive',  label: 'Archive',  Icon: IconArchive },
    { id: 'analysis', label: 'Analysis', Icon: IconAnalysis },
    { id: 'settings', label: 'Settings', Icon: IconSettings },
  ];
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 30,
      paddingBottom: 24,
    }}>
      <div style={{
        margin: '0 12px',
        background: theme.chrome,
        backdropFilter: 'blur(24px) saturate(160%)',
        WebkitBackdropFilter: 'blur(24px) saturate(160%)',
        borderTop: `0.5px solid ${theme.chromeBd}`,
        borderBottom: `0.5px solid ${theme.chromeBd}`,
        borderLeft: `0.5px solid ${theme.chromeBd}`,
        borderRight: `0.5px solid ${theme.chromeBd}`,
        borderRadius: 18,
        padding: '10px 6px 8px',
        display: 'flex', justifyContent: 'space-around',
        boxShadow: theme.dark
          ? '0 -2px 24px rgba(0,0,0,0.5), 0 0 0 1px rgba(232,162,74,0.05) inset'
          : '0 -2px 16px rgba(0,0,0,0.06), 0 1px 0 rgba(255,255,255,0.6) inset',
      }}>
        {items.map(({ id, label, Icon }) => {
          const on = id === active;
          const c = on ? theme.amber : theme.textDim;
          return (
            <button key={id} onClick={() => onChange(id)} style={{
              position: 'relative',
              flex: 1, background: 'transparent', border: 0, padding: '6px 0 4px',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
              color: c, cursor: 'pointer',
            }}>
              {/* active top line */}
              {on && <div style={{
                position: 'absolute', top: -1, left: '50%', transform: 'translateX(-50%)',
                width: 22, height: 1.2, background: theme.amber, borderRadius: 1,
                opacity: 0.85,
              }} />}
              <div style={{ position: 'relative' }}>
                <Icon size={22} />
                {on && <div style={{
                  position: 'absolute', top: -2, right: -3,
                  width: 5, height: 5, borderRadius: 999,
                  background: theme.amber,
                  boxShadow: theme.dark ? '0 0 6px rgba(255,178,58,0.6)' : 'none',
                }} />}
              </div>
              <span style={{
                fontSize: 10, fontWeight: on ? 600 : 500, letterSpacing: 0.3,
                fontFamily: 'Inter, sans-serif',
                color: on ? theme.text : theme.textDim,
              }}>{label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// SCREEN 1 — Daily Exercise Prompt
// ═════════════════════════════════════════════════════════════
function ScreenPrompt({ theme, t }) {
  return (
    <div style={{ position: 'relative', height: '100%', overflow: 'hidden' }}>
      <PGSubstrate theme={theme} intensity={t.substrate} seed={3} />

      <PGAppBar
        theme={theme}
        title="Plastiglom"
        subtitle="Main exercise · Evening"
        large={true}
        trailing={
          <div style={{
            width: 38, height: 38, borderRadius: 999,
            border: `0.5px solid ${theme.lineSoft}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: theme.textDim, marginTop: 4,
            background: theme.dark ? 'rgba(20,25,32,0.5)' : 'rgba(255,255,255,0.5)',
          }}>
            <IconWaning size={18} />
          </div>
        }
      />

      {/* fused exercise card */}
      <div style={{ padding: '10px 18px 0' }}>
        <FusedPanel theme={theme} variant={1} style={{ minHeight: 440, padding: '40px 28px' }}>
          {/* small star/asterisk top */}
          <div style={{ display: 'flex', justifyContent: 'center', marginTop: 6, marginBottom: 18 }}>
            <IconStar size={22} style={{ color: theme.gold }} />
          </div>

          <div style={{
            fontFamily: 'Fraunces, Georgia, serif',
            fontSize: 30, fontWeight: 400, color: theme.text,
            textAlign: 'center', letterSpacing: -0.4, marginBottom: 28,
          }}>Values drift check</div>

          <div style={{
            fontFamily: 'Fraunces, Georgia, serif',
            fontSize: 19, fontWeight: 300, color: theme.text,
            textAlign: 'center', lineHeight: 1.4,
            textWrap: 'pretty',
          }}>
            What did you want<br/>
            a year ago that<br/>
            you no longer want?
          </div>

          <div style={{
            display: 'flex', justifyContent: 'center',
            margin: '22px 0 18px',
          }}>
            <div style={{ width: 30, height: 0.5, background: theme.gold, opacity: 0.7 }} />
          </div>

          <div style={{
            fontFamily: 'Fraunces, Georgia, serif',
            fontSize: 17, fontWeight: 300, color: theme.textDim,
            textAlign: 'center', lineHeight: 1.45,
            textWrap: 'pretty',
            fontStyle: 'italic',
          }}>
            What does that shift<br/>
            reveal, if anything?
          </div>

          {/* meta footer */}
          <div style={{
            position: 'absolute', bottom: 22, left: 0, right: 0,
            display: 'flex', justifyContent: 'center', gap: 14,
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 10, letterSpacing: 0.6,
            color: theme.textFaint, textTransform: 'uppercase',
          }}>
            <span>Main</span>
            <span style={{ color: theme.gold }}>·</span>
            <span>Evening</span>
            <span style={{ color: theme.gold }}>·</span>
            <span>est. 8 min</span>
          </div>
        </FusedPanel>
      </div>

      {/* CTA + secondary */}
      <div style={{
        position: 'absolute', left: 18, right: 18, bottom: 110,
        display: 'flex', gap: 10,
      }}>
        <button style={{
          flex: 1, height: 56, borderRadius: 14,
          background: theme.dark ? '#E8E2D2' : '#1A1A1F',
          color: theme.dark ? '#0A0D10' : '#F8F7F4',
          border: 0,
          fontFamily: 'Inter, sans-serif',
          fontSize: 15, fontWeight: 500, letterSpacing: 0.2,
          cursor: 'pointer',
          boxShadow: theme.dark
            ? '0 6px 18px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,178,58,0.15) inset'
            : '0 6px 18px rgba(0,0,0,0.18), 0 1px 0 rgba(255,255,255,0.15) inset',
        }}>Open Exercise</button>
        <button style={{
          width: 56, height: 56, borderRadius: 14,
          background: theme.dark ? 'rgba(20,25,32,0.7)' : 'rgba(255,254,250,0.85)',
          border: `0.5px solid ${theme.lineSoft}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: theme.text, cursor: 'pointer',
        }}>
          <IconArchive size={22} />
        </button>
      </div>

      <PGTabBar theme={theme} active="today" />
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// SCREEN 2 — Response Writing
// ═════════════════════════════════════════════════════════════
function ScreenResponse({ theme, t }) {
  const text =
`A year ago I wanted a stable, impressive career and the validation that came with it.

Now I feel less drawn to status. I want time, depth in relationships, and work that feels honest.

The shift reveals that I'm tired of performing. I'm learning to choose alignment over approval.`;

  return (
    <div style={{ position: 'relative', height: '100%', overflow: 'hidden',
                  background: theme.bgInk }}>
      <PGSubstrate theme={theme} intensity={t.substrate * 0.7} seed={5} />

      {/* nav bar — back + title centered + ellipsis */}
      <div style={{
        position: 'relative', zIndex: 5,
        padding: '58px 18px 6px',
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <button style={{
          width: 38, height: 38, borderRadius: 12,
          background: theme.dark ? 'rgba(20,25,32,0.6)' : 'rgba(255,255,255,0.7)',
          border: `0.5px solid ${theme.lineSoft}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: theme.text, cursor: 'pointer',
        }}>
          <IconBack size={18} />
        </button>
        <div style={{ flex: 1, textAlign: 'center' }}>
          <div style={{
            fontFamily: 'Fraunces, Georgia, serif',
            fontSize: 17, color: theme.text, letterSpacing: -0.2,
          }}>Values drift check</div>
          <div style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 9.5, color: theme.textDim, letterSpacing: 0.6,
            textTransform: 'uppercase', marginTop: 2,
          }}>Main · Evening</div>
        </div>
        <div style={{ width: 38 }} />
      </div>

      {/* lock-status strip */}
      <div style={{
        margin: '14px 18px 0',
        padding: '10px 14px',
        display: 'flex', alignItems: 'center', gap: 10,
        borderRadius: 12,
        background: theme.dark ? 'rgba(20,25,32,0.55)' : 'rgba(255,254,250,0.75)',
        border: `0.5px solid ${theme.lineSoft}`,
      }}>
        <div style={{
          width: 28, height: 28, borderRadius: 8,
          background: theme.dark ? 'rgba(255,178,58,0.10)' : 'rgba(201,128,44,0.10)',
          color: theme.amber,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <IconUnlock size={15} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 12.5, color: theme.text, fontWeight: 500 }}>
            Editable until next main fire
          </div>
          <div style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 10, color: theme.textDim, letterSpacing: 0.5,
          }}>local · locks at 07:30</div>
        </div>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 13, color: theme.amber, letterSpacing: 0.5,
          fontWeight: 500,
        }}>07:30</div>
      </div>

      {/* response card (less ornate — utilitarian writing surface) */}
      <div style={{
        margin: '14px 18px 0',
        padding: '20px 20px 16px',
        borderRadius: 16,
        background: theme.dark ? 'rgba(15,18,22,0.65)' : 'rgba(255,254,250,0.85)',
        border: `0.5px solid ${theme.lineSoft}`,
        position: 'relative',
        minHeight: 280,
      }}>
        {/* faint kintsugi seam at top */}
        <svg width="100%" height="14" style={{ position: 'absolute', top: 6, left: 0, opacity: 0.5 }}
             preserveAspectRatio="none" viewBox="0 0 400 14">
          <path d="M 12 8 C 60 4, 110 12, 180 7 S 320 4, 388 9"
                stroke={theme.gold} strokeWidth="0.6" fill="none" />
        </svg>

        <div style={{
          fontFamily: 'Fraunces, Georgia, serif',
          fontSize: 16, lineHeight: 1.55, color: theme.text,
          whiteSpace: 'pre-wrap',
          textWrap: 'pretty',
        }}>{text}<span style={{
          display: 'inline-block', width: 1.5, height: 18, background: theme.amber,
          verticalAlign: 'middle', marginLeft: 1,
          animation: 'pgblink 1s steps(2) infinite',
        }} /></div>

        <style>{`@keyframes pgblink { 50% { opacity: 0; } }`}</style>
      </div>

      {/* save-state row */}
      <div style={{
        margin: '12px 18px 0',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10.5, color: theme.textDim, letterSpacing: 0.5,
      }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
          <IconCheck size={13} style={{ color: theme.sage }} />
          saved locally · 22 sec ago
        </span>
        <IconCloud size={14} style={{ color: theme.textFaint }} />
      </div>

      {/* action buttons */}
      <div style={{
        position: 'absolute', left: 18, right: 18, bottom: 110,
        display: 'flex', gap: 8,
      }}>
        <button style={{
          flex: 1, height: 44, borderRadius: 12,
          background: theme.dark ? 'rgba(20,25,32,0.8)' : 'rgba(255,254,250,0.9)',
          color: theme.text,
          border: `0.5px solid ${theme.lineSoft}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          fontSize: 13.5, fontWeight: 500, fontFamily: 'Inter, sans-serif',
          cursor: 'pointer',
        }}><IconEdit size={14} /> Edit</button>
        <button style={{
          flex: 1, height: 44, borderRadius: 12,
          background: theme.dark ? 'rgba(20,25,32,0.8)' : 'rgba(255,254,250,0.9)',
          color: theme.text,
          border: `0.5px solid ${theme.lineSoft}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 13.5, fontWeight: 500, fontFamily: 'Inter, sans-serif',
          cursor: 'pointer',
        }}>Save Draft</button>
        <button style={{
          flex: 1.1, height: 44, borderRadius: 12,
          background: theme.amber,
          color: theme.dark ? '#0A0D10' : '#FFFEFA',
          border: 0,
          fontSize: 13.5, fontWeight: 600, fontFamily: 'Inter, sans-serif',
          letterSpacing: 0.2, cursor: 'pointer',
          boxShadow: '0 4px 14px rgba(255,178,58,0.30)',
        }}>Submit</button>
      </div>

      {/* compact format/photo/tag/more bar above tabbar */}
      <div style={{
        position: 'absolute', left: 18, right: 18, bottom: 64,
        display: 'flex', justifyContent: 'space-around',
        color: theme.textDim,
        fontFamily: 'Inter, sans-serif',
        fontSize: 10, letterSpacing: 0.3,
      }}>
        {[
          { Icon: IconEdit, label: 'Format' },
          { Icon: IconPaperclip, label: 'Photo' },
          { Icon: IconTag, label: 'Tag' },
          { Icon: IconMore, label: 'More' },
        ].map(({ Icon, label }) => (
          <div key={label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
            <Icon size={18} />
            <span>{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// SCREEN 3 — History / Archive
// ═════════════════════════════════════════════════════════════
function ScreenArchive({ theme, t }) {
  const entries = [
    { date: 'May 13, 2026', time: '23:00', title: 'Values drift check', tags: ['values','change','identity'], status: 'synced' },
    { date: 'May 13, 2026', time: '07:30', title: 'Energy audit',       tags: ['energy','focus','boundaries'], status: 'local' },
    { date: 'May 11, 2026', time: '19:00', title: 'Gratitude inventory',tags: ['gratitude','mindset'],         status: 'local' },
    { date: 'May 11, 2026', time: '06:30', title: "What's heavy?",       tags: ['emotions','burden','clarity'], status: 'synced' },
    { date: 'May 10, 2026', time: '21:00', title: 'Future self letter',  tags: ['vision','identity','direction'], status: 'local' },
  ];
  const filters = ['All', 'Main', 'Evening', 'Null'];
  const [active, setActive] = React.useState('All');

  return (
    <div style={{ position: 'relative', height: '100%', overflow: 'hidden' }}>
      <PGSubstrate theme={theme} intensity={t.substrate * 0.6} seed={11} />

      <PGAppBar
        theme={theme}
        leading={
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <IconArchive size={22} style={{ color: theme.text }} />
            <div style={{
              fontFamily: 'Fraunces, Georgia, serif',
              fontSize: 26, fontWeight: 400, color: theme.text, letterSpacing: -0.3,
            }}>Archive</div>
          </div>
        }
      />

      {/* search */}
      <div style={{
        margin: '8px 18px 0',
        display: 'flex', alignItems: 'center', gap: 10,
        height: 42, borderRadius: 12,
        background: theme.dark ? 'rgba(20,25,32,0.6)' : 'rgba(255,254,250,0.85)',
        border: `0.5px solid ${theme.lineSoft}`,
        padding: '0 14px',
      }}>
        <IconSearch size={16} style={{ color: theme.textDim }} />
        <span style={{
          flex: 1, color: theme.textFaint,
          fontSize: 14, fontFamily: 'Inter, sans-serif',
        }}>Search entries…</span>
      </div>

      {/* filter chips */}
      <div style={{
        margin: '12px 18px 8px',
        display: 'flex', alignItems: 'center', gap: 6,
      }}>
        {filters.map((f) => {
          const on = f === active;
          return (
            <button key={f} onClick={() => setActive(f)} style={{
              height: 30, padding: '0 12px', borderRadius: 999,
              background: on
                ? (theme.dark ? '#E8E2D2' : '#1A1A1F')
                : (theme.dark ? 'rgba(20,25,32,0.5)' : 'rgba(255,254,250,0.7)'),
              color: on
                ? (theme.dark ? '#0A0D10' : '#F8F7F4')
                : theme.textDim,
              border: on ? 0 : `0.5px solid ${theme.lineSoft}`,
              fontSize: 12, fontWeight: 500, fontFamily: 'Inter, sans-serif',
              cursor: 'pointer',
            }}>{f}</button>
          );
        })}
        <div style={{ flex: 1 }} />
        <button style={{
          width: 30, height: 30, borderRadius: 999,
          background: theme.dark ? 'rgba(20,25,32,0.5)' : 'rgba(255,254,250,0.7)',
          border: `0.5px solid ${theme.lineSoft}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: theme.textDim, cursor: 'pointer',
        }}>
          <IconFilter size={14} />
        </button>
      </div>

      {/* entry list — archive slabs */}
      <div style={{
        padding: '4px 14px 100px',
        overflow: 'hidden',
        display: 'flex', flexDirection: 'column', gap: 10,
      }}>
        {entries.map((e, i) => {
          const statusColor = e.status === 'synced' ? theme.sage
            : e.status === 'local' ? theme.amber : theme.textDim;
          const slabClip = 'polygon(2% 0, 100% 0, 100% 70%, 96% 100%, 0 100%, 0 14%)';
          return (
            <div key={i} style={{
              position: 'relative',
              background: theme.dark ? 'rgba(22,27,33,0.78)' : 'rgba(255,255,254,0.85)',
              clipPath: slabClip,
              WebkitClipPath: slabClip,
              padding: '12px 18px 12px 16px',
            }}>
              <div style={{
                position: 'absolute', inset: 0,
                clipPath: slabClip, WebkitClipPath: slabClip,
                boxShadow: theme.dark
                  ? '0 0 0 1px rgba(220,225,235,0.06) inset'
                  : '0 0 0 1px rgba(40,46,54,0.10) inset',
                pointerEvents: 'none',
              }} />
              {/* faint embedded trace */}
              <svg style={{ position: 'absolute', left: 8, top: 6, width: 28, height: 4,
                            pointerEvents: 'none', opacity: 0.5 }} viewBox="0 0 28 4">
                <path d="M0 2 L8 2 L10 0 L20 0 L22 2 L28 2"
                      stroke={theme.dark ? 'rgba(220,225,235,0.20)' : 'rgba(40,46,54,0.22)'}
                      strokeWidth="0.6" fill="none" />
              </svg>

              <div style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: 9.5, letterSpacing: 0.6, textTransform: 'uppercase',
                color: theme.textDim, marginBottom: 6,
              }}>
                <span>{e.date} · {e.time}</span>
                <span style={{
                  color: statusColor,
                  display: 'inline-flex', alignItems: 'center', gap: 5,
                }}>
                  <StatusNode kind={e.status} size={10} color={statusColor} />
                  {e.status}
                </span>
              </div>
              <div style={{
                fontFamily: 'Fraunces, Georgia, serif',
                fontSize: 17, color: theme.text, marginBottom: 8, letterSpacing: -0.2,
              }}>{e.title}</div>
              <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                {e.tags.map((tag) => <Tag key={tag} theme={theme}>{tag}</Tag>)}
              </div>
            </div>
          );
        })}
      </div>

      <PGTabBar theme={theme} active="archive" />
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// SCREEN 4 — Weekly / Monthly Analysis
// ═════════════════════════════════════════════════════════════
function ScreenAnalysis({ theme, t }) {
  const [tab, setTab] = React.useState('Weekly');
  const tabs = ['Weekly', 'Monthly', 'Ad-hoc'];

  return (
    <div style={{ position: 'relative', height: '100%', overflow: 'hidden' }}>
      <PGSubstrate theme={theme} intensity={t.substrate * 0.65} seed={9} />

      <PGAppBar
        theme={theme}
        leading={
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <IconAnalysis size={22} style={{ color: theme.text }} />
            <div style={{
              fontFamily: 'Fraunces, Georgia, serif',
              fontSize: 26, fontWeight: 400, color: theme.text, letterSpacing: -0.3,
            }}>Analysis</div>
          </div>
        }
      />

      {/* segmented control */}
      <div style={{ margin: '6px 18px 0' }}>
        <div style={{
          display: 'flex', padding: 3, borderRadius: 12,
          background: theme.dark ? 'rgba(20,25,32,0.6)' : 'rgba(220,217,211,0.55)',
          border: `0.5px solid ${theme.lineSoft}`,
        }}>
          {tabs.map((tb) => {
            const on = tb === tab;
            return (
              <button key={tb} onClick={() => setTab(tb)} style={{
                flex: 1, height: 32, borderRadius: 9,
                background: on
                  ? theme.amber
                  : 'transparent',
                color: on
                  ? (theme.dark ? '#0A0D10' : '#FFFEFA')
                  : theme.textDim,
                border: 0,
                fontSize: 12.5, fontWeight: 600, fontFamily: 'Inter, sans-serif',
                letterSpacing: 0.2, cursor: 'pointer',
                boxShadow: on ? '0 2px 8px rgba(255,178,58,0.30)' : 'none',
              }}>{tb}</button>
            );
          })}
        </div>
      </div>

      {/* date range */}
      <div style={{
        margin: '12px 18px 0',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 4px',
      }}>
        <button style={{
          width: 30, height: 30, borderRadius: 8, border: 0,
          background: 'transparent', color: theme.textDim, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}><IconChevronLeft size={16} /></button>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 12, color: theme.text, letterSpacing: 0.4,
        }}>May 6 – May 12, 2026</div>
        <button style={{
          width: 30, height: 30, borderRadius: 8, border: 0,
          background: 'transparent', color: theme.textDim, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}><IconChevron size={16} /></button>
      </div>

      {/* report sections */}
      <div style={{
        padding: '14px 18px 100px',
        overflow: 'hidden',
        display: 'flex', flexDirection: 'column', gap: 14,
      }}>
        <ReportSection theme={theme} label="Observations" gold>
          You questioned what you want more than you affirmed what you have. A pattern of re-evaluation.
        </ReportSection>

        <ReportSection theme={theme} label="Contradictions">
          You seek simplicity, yet overcommit. You value rest, yet resist slowing down.
        </ReportSection>

        <ReportSection theme={theme} label="Recommendations">
          <div style={{ marginBottom: 6 }}>Protect one non-negotiable block of unscheduled time daily.</div>
          <div>Decline one optional commitment this week.</div>
        </ReportSection>

        <div>
          <div style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 9.5, letterSpacing: 1, textTransform: 'uppercase',
            color: theme.textDim, marginBottom: 10, marginLeft: 2,
          }}>Recurring Themes</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {['identity','values','time','clarity','purpose','boundaries'].map((tag, i) => (
              <Tag key={tag} theme={theme} variant={i < 2 ? 'amber' : 'default'}>{tag}</Tag>
            ))}
          </div>
        </div>
      </div>

      <PGTabBar theme={theme} active="analysis" />
    </div>
  );
}

function ReportSection({ theme, label, children, gold = false }) {
  return (
    <div style={{ position: 'relative' }}>
      <div style={{
        position: 'absolute', left: -2, top: 4, bottom: 4, width: 1.5,
        background: gold ? theme.gold : theme.lineSoft, opacity: gold ? 0.85 : 1,
      }} />
      <div style={{ paddingLeft: 12 }}>
        <div style={{
          fontFamily: 'Fraunces, Georgia, serif',
          fontSize: 17, color: theme.text, marginBottom: 6, letterSpacing: -0.2,
        }}>{label}</div>
        <div style={{
          fontFamily: 'Inter, sans-serif', fontSize: 13.5, lineHeight: 1.55,
          color: theme.textDim, textWrap: 'pretty',
        }}>{children}</div>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// SCREEN 5 — Settings / Reminders
// ═════════════════════════════════════════════════════════════
function ScreenSettings({ theme, t }) {
  const [notif, setNotif] = React.useState(true);

  return (
    <div style={{ position: 'relative', height: '100%', overflow: 'hidden' }}>
      <PGSubstrate theme={theme} intensity={t.substrate * 0.6} seed={7} />

      <PGAppBar
        theme={theme}
        leading={
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <IconSettings size={22} style={{ color: theme.text }} />
            <div style={{
              fontFamily: 'Fraunces, Georgia, serif',
              fontSize: 26, fontWeight: 400, color: theme.text, letterSpacing: -0.3,
            }}>Settings</div>
          </div>
        }
      />

      <div style={{ padding: '8px 18px 100px', overflow: 'hidden',
                    display: 'flex', flexDirection: 'column', gap: 18 }}>

        {/* main exercise time */}
        <SettingsGroup theme={theme} label="Main Exercise Time">
          <SettingsRow theme={theme} icon={<IconSun size={18} style={{color: theme.amber}} />}
                       label="Morning" detail="07:30" chevron />
          <SettingsRow theme={theme} icon={<IconMoon size={18} style={{color: theme.textDim}} />}
                       label="Evening" detail="21:00" chevron />
        </SettingsGroup>

        {/* reminders */}
        <SettingsGroup theme={theme} label="Reminders">
          <SettingsRow theme={theme} icon={<IconBell size={18} style={{color: theme.textDim}} />}
                       label="Reminder before main" detail="15 min before" chevron />
          <SettingsRow theme={theme} label="Missed reminder follow-up" detail="2 hours later" chevron />
          <SettingsRow theme={theme} label="Enable notifications"
                       trailing={<Toggle theme={theme} value={notif} onChange={setNotif} />} />
        </SettingsGroup>

        {/* private vault */}
        <FusedPanel theme={theme} variant={4} style={{ padding: '14px 16px' }} seam={false}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: theme.dark ? 'rgba(255,178,58,0.10)' : 'rgba(201,128,44,0.10)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: theme.amber,
            }}><IconLock size={17} /></div>
            <div style={{ flex: 1 }}>
              <div style={{
                fontSize: 13, fontWeight: 600, color: theme.text,
                fontFamily: 'Inter, sans-serif',
              }}>Private vault · Local-first</div>
              <div style={{
                fontSize: 11, color: theme.textDim, marginTop: 2,
                fontFamily: 'Inter, sans-serif',
              }}>Your data stays on this device.</div>
            </div>
            <IconChevron size={14} style={{ color: theme.textFaint }} />
          </div>
        </FusedPanel>

        {/* meta footer notes */}
        <div style={{
          marginTop: 4, padding: '0 4px',
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 10, lineHeight: 1.7, color: theme.textFaint,
          letterSpacing: 0.3,
        }}>
          <div>· main exercise fires at set times</div>
          <div>· response editable until next main fire</div>
          <div>· all data is private and stored locally</div>
          <div>· analysis is generated on-device</div>
          <div>· telegram used only for notifications</div>
        </div>
      </div>

      <PGTabBar theme={theme} active="settings" />
    </div>
  );
}

function SettingsGroup({ theme, label, children }) {
  return (
    <div>
      <div style={{
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 9.5, letterSpacing: 1, textTransform: 'uppercase',
        color: theme.textDim, marginBottom: 8, marginLeft: 4,
      }}>{label}</div>
      <div style={{
        background: theme.dark ? 'rgba(20,25,32,0.6)' : 'rgba(255,254,250,0.85)',
        border: `0.5px solid ${theme.lineSoft}`,
        borderRadius: 14, overflow: 'hidden',
      }}>{children}</div>
    </div>
  );
}

function SettingsRow({ theme, icon, label, detail, chevron, trailing }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '12px 14px', minHeight: 46,
      borderBottom: `0.5px solid ${theme.lineSoft}`,
    }}>
      {icon && (
        <div style={{
          width: 28, height: 28, borderRadius: 7,
          background: theme.dark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{icon}</div>
      )}
      <div style={{
        flex: 1, fontSize: 13.5, color: theme.text,
        fontFamily: 'Inter, sans-serif',
      }}>{label}</div>
      {detail && (
        <div style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 12, color: theme.textDim, letterSpacing: 0.3,
        }}>{detail}</div>
      )}
      {trailing}
      {chevron && <IconChevron size={13} style={{ color: theme.textFaint }} />}
    </div>
  );
}

function Toggle({ theme, value, onChange }) {
  return (
    <button onClick={() => onChange(!value)} style={{
      position: 'relative', width: 38, height: 22, borderRadius: 999,
      background: value ? theme.amber : (theme.dark ? '#2A313B' : '#C8C5BE'),
      border: 0, padding: 0, cursor: 'pointer',
      transition: 'background 0.18s',
    }}>
      <div style={{
        position: 'absolute', top: 2, left: value ? 18 : 2,
        width: 18, height: 18, borderRadius: 999,
        background: '#FFFEFA',
        boxShadow: '0 1px 2px rgba(0,0,0,0.25)',
        transition: 'left 0.18s',
      }} />
    </button>
  );
}

Object.assign(window, {
  pgTheme, PGSubstrate, FusedPanel, PGAppBar, PGTabBar, Tag,
  ScreenPrompt, ScreenResponse, ScreenArchive, ScreenAnalysis, ScreenSettings,
});
